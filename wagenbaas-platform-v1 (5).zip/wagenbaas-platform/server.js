require("dotenv").config();
const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const path = require("path");
const crypto = require("crypto");
const { initDB, db } = require("./database");
const { getAIReply, extractData, cleanReply, AI_PROVIDER } = require("./ai");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "wagenbaas-admin-2024";

app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));
app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({ windowMs: 10 * 60 * 1000, max: 60,
  message: { error: "Te veel verzoeken." }
}));

// ── Load enabled channels ─────────────────────────────────────────────────────
const channels = {
  sms:       process.env.ENABLE_SMS       === "true",
  email:     process.env.ENABLE_EMAIL     === "true",
  whatsapp:  process.env.ENABLE_WHATSAPP  === "true",
  facebook:  process.env.ENABLE_FACEBOOK  === "true",
  instagram: process.env.ENABLE_INSTAGRAM === "true",
  voice:     process.env.ENABLE_VOICE     === "true",
};

if (channels.sms)       require("./channels/sms").register(app);
if (channels.email)     require("./channels/email").register(app);
if (channels.whatsapp)  require("./channels/whatsapp").register(app);
if (channels.facebook)  require("./channels/facebook").register(app);
if (channels.instagram) require("./channels/instagram").register(app);
if (channels.voice)     require("./channels/voice").register(app);

// ── Welcome ───────────────────────────────────────────────────────────────────
app.get("/api/welcome", (req, res) => {
  res.json({
    message: "Welkom. How can I help you with?"
  });
});

// ── Main Chat API ─────────────────────────────────────────────────────────────
app.post("/api/chat", async (req, res) => {
  const { messages, sessionId, channel = "webchat" } = req.body;
  if (!messages || !Array.isArray(messages)) return res.status(400).json({ error: "Ongeldig formaat." });

  const valid = messages.every(m =>
    (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim()
  );
  if (!valid) return res.status(400).json({ error: "Ongeldig formaat." });

  const sid = sessionId || crypto.randomUUID();
  const trimmed = messages.slice(-20);
  const lastMsg = trimmed[trimmed.length - 1];

  if (lastMsg?.role === "user") {
    db.insertMessage({ $session_id: sid, $channel: channel, $direction: "inbound", $from_id: sid, $from_name: "Klant", $content: lastMsg.content });
    db.insertStat({ $event: "message_sent", $channel: channel, $meta: null });
  }

  try {
    const rawReply = await getAIReply(trimmed);
    const { appointment, lead, callback } = extractData(rawReply);
    const reply = cleanReply(rawReply);

    db.insertMessage({ $session_id: sid, $channel: channel, $direction: "outbound", $from_id: "wagenbaas", $from_name: "Wagenbaas AI", $content: reply });

    if (appointment) {
      db.insertAppointment({ $name: appointment.name||"", $phone: appointment.phone||"", $email: appointment.email||"", $car_brand: appointment.car_brand||"", $car_model: appointment.car_model||"", $car_year: appointment.car_year||"", $license: appointment.license||"", $service: appointment.service||"", $pref_date: appointment.pref_date||"", $pref_time: appointment.pref_time||"", $notes: appointment.notes||"", $channel: channel });
      db.insertStat({ $event: "appointment_booked", $channel: channel, $meta: appointment.service });
    }
    if (callback) {
      db.insertCallback({ $name: callback.name||"", $phone: callback.phone||"", $reason: callback.reason||"", $channel: channel });
      db.insertStat({ $event: "callback_requested", $channel: channel, $meta: callback.phone });
    }
    if (lead) {
      db.insertLead({ $name: lead.name||"", $phone: lead.phone||"", $email: lead.email||"", $source: channel, $notes: lead.notes||"" });
      db.insertStat({ $event: "lead_captured", $channel: channel, $meta: null });
    }

    res.json({ reply, sessionId: sid, appointment: !!appointment, callback: !!callback, lead: !!lead });

  } catch (err) {
    console.error("AI error:", err.message);
    res.status(500).json({ error: "Er is een fout opgetreden. Controleer uw API sleutel." });
  }
});

// ── Admin Auth ────────────────────────────────────────────────────────────────
function adminAuth(req, res, next) {
  const token = req.headers["x-admin-token"] || req.query.token;
  if (token !== ADMIN_TOKEN) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// ── Admin API ─────────────────────────────────────────────────────────────────
app.get("/api/admin/dashboard", adminAuth, (req, res) => {
  res.json({
    appointments:   db.allAppointments(),
    callbacks:      db.allCallbacks(),
    leads:          db.allLeads(),
    messages:       db.allMessages(),
    stats:          db.statsCount(),
    todayStats:     db.todayStats(),
    channelStats:   db.channelStats(),
    activeChannels: channels,
    aiProvider:     AI_PROVIDER,
  });
});

app.patch("/api/admin/appointments/:id", adminAuth, (req, res) => {
  const { status } = req.body;
  if (!["nieuw","bevestigd","afgerond","geannuleerd"].includes(status)) return res.status(400).json({ error: "Ongeldige status" });
  db.updateAppointmentStatus({ $status: status, $id: req.params.id });
  res.json({ ok: true });
});

app.patch("/api/admin/callbacks/:id", adminAuth, (req, res) => {
  const { status } = req.body;
  if (!["te bellen","gebeld","afgerond"].includes(status)) return res.status(400).json({ error: "Ongeldige status" });
  db.updateCallbackStatus({ $status: status, $id: req.params.id });
  res.json({ ok: true });
});

// ── Routes ────────────────────────────────────────────────────────────────────
app.get("/api/health", (req, res) => res.json({ status: "ok", provider: AI_PROVIDER, channels }));
app.get("/tiktok", (req, res) => res.sendFile(path.join(__dirname, "public", "tiktok.html")));
app.get("/boek", (req, res) => res.sendFile(path.join(__dirname, "public", "tiktok.html")));
app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

// ── Start ─────────────────────────────────────────────────────────────────────
initDB().then(() => {
  app.listen(PORT, () => {
    console.log(`\n🚗 Implementit Platform → http://localhost:${PORT}`);
    console.log(`🤖 AI: ${AI_PROVIDER.toUpperCase()}`);
    console.log(`🎵 TikTok booking page → http://localhost:${PORT}/tiktok`);
    console.log(`🔐 Admin → http://localhost:${PORT}/admin  (token: ${ADMIN_TOKEN})`);
    console.log(`\n📡 Actieve kanalen:`);
    Object.entries(channels).forEach(([k,v]) => console.log(`   ${v ? '✅' : '⬜'} ${k}`));
    console.log('');
  });
}).catch(err => { console.error("DB error:", err); process.exit(1); });
