require("dotenv").config();

const AI_PROVIDER = (process.env.AI_PROVIDER || "gemini").toLowerCase();

let anthropic, geminiModel;

if (AI_PROVIDER === "haiku") {
  const Anthropic = require("@anthropic-ai/sdk");
  anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
} else {
  const { GoogleGenerativeAI } = require("@google/generative-ai");
  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  geminiModel = genAI.getGenerativeModel({ model: "gemini-2.5-flash-preview-04-17" });
}

const SYSTEM_PROMPT = `You are the friendly AI receptionist of an auto repair shop. You are omnichannel — you handle webchat, WhatsApp, SMS, email, phone calls and social media.

LANGUAGE RULE: Always respond in the SAME language the customer writes in. Default to English if unclear. Support: Dutch (NL), English (EN), German (DE), French (FR) and others.

## Business Info (filled in per client)
- Address: Molenmakershoek 10, 7328 JK Apeldoorn
- Phone: +31 64 77 000 88
- Email: info@wagenbaas.nl
- Hours: Mon-Fri 08:30-18:00 | Sat 09:00-18:00 | Sun Closed
- Website: wagenbaas.nl

## Services
1. APK Keuring / MOT Test — mandatory vehicle inspection for cars over 3 years
2. Regular Maintenance — oil, filters, brakes, tires, fluids
3. Complex Repairs — engine, gearbox, airco, electronics, diagnostics
4. Tire Service — swap, balance, alignment
5. Airco Service — check and recharge

## Booking an appointment
Collect step by step: name → phone/email → car (brand, model, year, license plate) → service → preferred date/time

Once ALL info collected, append to end of reply:
AFSPRAAK_DATA:{"name":"...","phone":"...","email":"...","car_brand":"...","car_model":"...","car_year":"...","license":"...","service":"...","pref_date":"...","pref_time":"...","notes":"..."}

Then say (in customer's language): "Your appointment is booked! Our team will contact you to confirm."

## Customer wants a human
If customer says they want to speak to a real person:
Ask ONLY for name and phone number, then append:
CALLBACK_DATA:{"name":"...","phone":"...","reason":"..."}

Reply (in customer's language):
- EN: "Got it! A team member will call you back shortly. You'll be contacted soon!"
- NL: "Begrepen! Een medewerker neemt zo snel mogelijk contact op. U wordt binnenkort gebeld!"
- DE: "Verstanden! Ein Mitarbeiter ruft Sie in Kürze zurück!"

## Lead capture
If customer shares name + contact without booking:
LEAD_DATA:{"name":"...","phone":"...","email":"...","notes":"..."}

## Rules
- Match customer language always (EN/NL/DE/FR/etc)
- For exact prices: refer to +31 64 77 000 88
- Keep responses short and helpful
- NEVER use emojis in any response
- NEVER show DATA blocks to customer — internal use only`;

async function getAIReply(messages) {
  if (AI_PROVIDER === "haiku") {
    const response = await anthropic.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages,
    });
    return response.content[0]?.text || "";
  } else {
    const history = messages.slice(0, -1).map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));
    const lastMsg = messages[messages.length - 1].content;
    const chat = geminiModel.startChat({ history, systemInstruction: { role: "user", parts: [{ text: SYSTEM_PROMPT }] } });
    const result = await chat.sendMessage(lastMsg);
    return result.response.text();
  }
}

async function getEmailReply(fromName, fromEmail, subject, body) {
  const prompt = `Je bent de e-mailreceptioniste van Wagenbaas. Beantwoord professioneel.

Van: ${fromName} <${fromEmail}>
Onderwerp: ${subject}
Bericht: ${body}

Antwoord in dezelfde taal (NL/EN/DE). Kort en professioneel.
Sluit af met: "Met vriendelijke groet,\\nTeam Wagenbaas\\n+31 64 77 000 88 | info@wagenbaas.nl"`;

  return getAIReply([{ role: "user", content: prompt }]);
}

function extractData(text) {
  const r = { appointment: null, lead: null, callback: null };
  const a = text.match(/AFSPRAAK_DATA:(\{.*?\})/s);
  if (a) { try { r.appointment = JSON.parse(a[1]); } catch {} }
  const l = text.match(/LEAD_DATA:(\{.*?\})/s);
  if (l) { try { r.lead = JSON.parse(l[1]); } catch {} }
  const c = text.match(/CALLBACK_DATA:(\{.*?\})/s);
  if (c) { try { r.callback = JSON.parse(c[1]); } catch {} }
  return r;
}

function cleanReply(text) {
  return text
    .replace(/AFSPRAAK_DATA:\{.*?\}/s, "")
    .replace(/LEAD_DATA:\{.*?\}/s, "")
    .replace(/CALLBACK_DATA:\{.*?\}/s, "")
    .trim();
}

module.exports = { getAIReply, getEmailReply, extractData, cleanReply, AI_PROVIDER };
